﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookShopManagement
{
    class Bookstore
    {
        public int MaSach { get; set; }
        public string TenSach { get; set; }
        public int TongSoLuong { get; set; }
        public int SoLuongCon { get; set; }
    }
}
