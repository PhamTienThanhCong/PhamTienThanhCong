﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PBL3_BookShopManagement.DTO
{
    class ThongTinXuatBan
    {
        public int MaSach { get; set; }
        public string LanTaiBan { get; set; }
        public string NamXuatBan { get; set; }
        public string NhaXuatBan { get; set; }
        public int GiaBia { get; set; }
    }
}
