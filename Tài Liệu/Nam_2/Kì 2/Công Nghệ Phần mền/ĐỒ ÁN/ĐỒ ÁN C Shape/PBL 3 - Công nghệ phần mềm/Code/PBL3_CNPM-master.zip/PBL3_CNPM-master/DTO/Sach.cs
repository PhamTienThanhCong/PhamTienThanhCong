﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookShopManagement.DTO
{
    class Sach
    {
        public int MaSach { get; set; }
        public string TenSach { get; set; }
        public int DonGia { get; set; }
        public string TenLoaiSach { get; set; }
        public string TenTacGia { get; set; }
        public string TenLinhVuc { get; set; }
    }
}
