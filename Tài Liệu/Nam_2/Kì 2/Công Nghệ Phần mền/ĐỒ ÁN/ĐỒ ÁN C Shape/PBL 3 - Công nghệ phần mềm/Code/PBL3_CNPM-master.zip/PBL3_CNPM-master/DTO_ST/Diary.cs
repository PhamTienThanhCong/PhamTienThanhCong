﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookShopManagement
{
    class Diary
    {
        public int STT { get; set; }
        public int MaSach { get; set; }
        public int SoLuong { get; set; }
        public DateTime NgayNhap { get; set; }
        public int ID_Staff { get; set; }
    }
}
