﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PBL3_BookShopManagement.DTO
{
    class Position
    {
        public int ID_Position { get; set; }
        public string NamePosition { get; set; }
    }
}
