﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PBL3_BookShopManagement.DTO
{
    class SachKhuyenMai
    { 
        public int MaSach { get; set; }
        public float MucGiamGia { get; set; }
    }
}
