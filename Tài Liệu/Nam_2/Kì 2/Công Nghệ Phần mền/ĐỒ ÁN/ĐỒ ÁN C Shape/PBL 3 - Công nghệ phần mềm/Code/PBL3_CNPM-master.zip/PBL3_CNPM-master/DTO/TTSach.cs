﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookShopManagement.DTO
{
    public class TTSach
    {
        //public int MaHD { get; set; }
        public int MaSach { get; set; }
        public string TenSach{ get; set; }
        public int SoLuong { get; set; }
        public int DonGia { get; set; }
        //public float MucGiamGia { get; set; }
        public float MucGiamGia { get; set; }
        public decimal ThanhTien { get; set; }
    }
}
