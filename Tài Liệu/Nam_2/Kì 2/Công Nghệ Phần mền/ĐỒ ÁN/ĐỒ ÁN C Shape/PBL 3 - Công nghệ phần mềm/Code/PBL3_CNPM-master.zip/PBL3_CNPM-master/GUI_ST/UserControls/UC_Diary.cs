﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BookShopManagement.Forms;
using BookShopManagement.BLL_ST;

namespace BookShopManagement.UserControls
{
    public partial class UC_Diary : UserControl
    {
        public UC_Diary()
        {
            InitializeComponent();
            dataGridView2.DataSource = CSDL_OOP.Instance.GetDiaries();
            setCBB();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != -1)
            {

                List<Diary> dt = new List<Diary>();
                if (textBox1.Text == "")
                {
                    dt = CSDL_OOP.Instance.GetDiaries();
                }
                else dt = CSDL_OOP.Instance.GetDiaries();
                string sortBy = comboBox1.SelectedItem.ToString();
                switch (sortBy)
                {
                    case "STT":
                        dataGridView2.DataSource = dt.OrderBy(o => o.STT).ToList();
                        break;
                    case "MaSach":
                        dataGridView2.DataSource = dt.OrderBy(o => o.MaSach).ToList();
                        break;
                    case "SoLuong":
                        dataGridView2.DataSource = dt.OrderBy(o => o.SoLuong).ToList();
                        break;
                    case "NgayNhap":
                        dataGridView2.DataSource = dt.OrderBy(o => o.NgayNhap).ToList();
                        break;
                    case "ID_Staff":
                        dataGridView2.DataSource = dt.OrderBy(o => o.ID_Staff).ToList();
                        break;
                }
                /* dataGridView2.Columns[0].HeaderText = "Book ID";
                 dataGridView2.Columns[1].HeaderText = "Book Title";
                 dataGridView2.Columns[2].HeaderText = "Cost Price";
                 dataGridView2.Columns[3].HeaderText = "So luong con";*/
            }
        }
        private void setCBB()
        {
            int count = 0;
            foreach (DataColumn i in CSDL_USER.Instance.Diary.Columns)
            {
                comboBox1.Items.Add(new CBBItems()
                {
                    Text = i.ColumnName,
                    value = count
                });
                count++;
            }
            comboBox1.SelectedIndex = -1;
        }
    }
}
