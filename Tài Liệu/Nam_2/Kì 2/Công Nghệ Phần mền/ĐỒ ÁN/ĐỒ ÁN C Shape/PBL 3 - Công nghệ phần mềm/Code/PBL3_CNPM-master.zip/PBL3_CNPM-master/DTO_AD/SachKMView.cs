﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PBL3_BookShopManagement.DTO
{
    class SachKMView
    {
        public int MaSach { get; set; }
        public string TenSach { get; set; }
        public int GiaBia { get; set; }
        public double MucGiamGia { get; set; }
        public double GiaSauKM { get; set; }

    }
}