use Quan_Ly_Sinh_Vien
go
--1.In danh sách các sinh viên của 1 lớp học
-- Phải có mã lớp
-- Tìm tất cả sinh viên dựa theo mã lớp

create proc in_danh_sach_lop
	 @malop varchar(10)
as
begin
	--set @malop = 'TH2002/01'
	select Sinh_Vien.* from Sinh_Vien
	LEFT JOIN Lop ON Sinh_Vien.Ma_Lop = @malop
end

-- in_danh_sach_lop 'TH2002/01'

go

-- 2.Nhập vào 1 môn học và 1 mã sv, kiểm tra xem sinh viên có đậu môn này trong
-- lần thi đầu tiên không, nếu đậu thì xuất ra là “Đậu”, không thì xuất ra “Không đậu”
create proc check_qua_mon
	 @masv varchar(10),
	 @mamh varchar(10)
as
begin
if (exists (select * from Ket_Qua 
	where Ket_Qua.MaSV = @masv
	and Ket_Qua.MaMH = @mamh
	and Ket_Qua.Lan_Thi = 1
	and Ket_Qua.Diem_Thi >= 5))
	print N'Đậu'
else
	print N'Không Đậu'
end
go

-- check_qua_mon '0212002', 'THT01'

go
-- cách 2 không dùng exists
CREATE PROC check_qua_mon_2
    @masv VARCHAR(10) ,
    @mamh VARCHAR(10)
AS
    BEGIN
        DECLARE @diem FLOAT
        SELECT  @diem = Diem_Thi
        FROM    dbo.Ket_Qua
        WHERE   MaSV = @masv
                AND MaMH = @mamh
                AND Lan_Thi = 1
        IF ( @diem < 5 )
            PRINT N'Không đậu'
        ELSE
			PRINT N'Đậu'
    END

-- check_qua_mon_2 '0212002', 'THT01'

go


-- 3. Nhập vào 1 khoa, in danh sách các sinh viên (mã sinh viên, họ tên, ngày sinh) thuộc khoa này.

CREATE PROC in_danh_sach_khoa
    @makhoa VARCHAR(10)
AS
begin
	select Sinh_Vien.* from Sinh_Vien
	LEFT JOIN Lop ON Sinh_Vien.Ma_Lop = Lop.Ma_Lop
	LEFT JOIN Khoa ON Lop.Ma_Khoa = Khoa.Ma_Khoa
end
go

-- in_danh_sach_khoa 'VL'

-- .4 Nhập vào 1 sinh viên và 1 môn học, in điểm thi của sinh viên này của các lần
--thi môn học đó.

CREATE PROC kq_thi_va_diem
    @masv VARCHAR(10) ,
    @mamh VARCHAR(10)
AS
BEGIN
	select Ket_Qua.Lan_Thi, Ket_Qua.Diem_Thi from Ket_Qua 
	where Ket_Qua.MaSV = @masv
	and Ket_Qua.MaMH = @mamh
end
go

-- kq_thi_va_diem '0212001', 'THT01'

-- 5. Nhập vào 1 sinh viên, in ra các môn học mà sinh viên này phải học.

CREATE PROC mon_hoc_can_hoc
    @masv VARCHAR(10)
AS
begin
	select Mon_Hoc.* from Mon_Hoc
	LEFT JOIN Khoa ON Mon_Hoc.Ma_Khoa = Khoa.Ma_Khoa 
	LEFT JOIN Lop ON Lop.Ma_Khoa = Khoa.Ma_Khoa
	LEFT JOIN Sinh_Vien on Sinh_Vien.Ma_Lop = Lop.Ma_Lop
	where Sinh_Vien.MaSV = @masv
end
go

-- mon_hoc_can_hoc '0212001'

-- 6. Nhập vào 1 môn học, in danh sách các sinh viên đậu môn này trong lần thi đầu tiên.

CREATE PROC danh_sach_dau @mamh VARCHAR(10)
AS
    BEGIN
        SELECT  *
        FROM    dbo.Ket_Qua
        WHERE   MaMH = @mamh
                AND Lan_Thi = 1
                AND Diem_Thi > 5
    END
GO

-- danh_sach_dau 'THT01'

-- 7. In điểm các môn học của sinh viên có mã số là maSinhVien được nhập vào.
-- Chú ý: điểm của môn học là điểm thi của lần thi sau cùng
CREATE PROC in_diem_sinh_vien @masv VARCHAR(10)
AS
    BEGIN
	
        SELECT  *
        FROM    dbo.Ket_Qua KQ
        WHERE   KQ.MaSV = @masv
                AND KQ.Lan_Thi = ( SELECT    MAX(KQ2.Lan_Thi)
                                  FROM      Ket_Qua KQ2
                                  WHERE     KQ2.MaSV = KQ.MaSV
                                            AND KQ2.MaMH = KQ.MaMH
                                )
    END
GO

-- in_diem_sinh_vien '0212002'